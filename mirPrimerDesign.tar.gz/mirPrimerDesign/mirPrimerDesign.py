#!/usr/bin/python3
import sys,random
import builtins
from collections import defaultdict 
from builtins import input

##to read the fasta file with mature sequences of the miRNA
fastaFilename= input("Enter the name of the fasta file containing mature miRNA sequence(s):\n*Note: The file should be in the typical fasta format*\n")
mirna_fasta={}
#with open(sys.argv[1],'r') as fasta_file:
with open(fastaFilename,'r') as fasta_file:
    for line in fasta_file:
        line=line.strip()
        if not line:
            continue
        if line.startswith(">"):
            seq_name=line[1:]
            if seq_name not in mirna_fasta:
                mirna_fasta[seq_name] = []
            continue
        seq=line
        mirna_fasta[seq_name].append(seq)
##output to be written to another txt file
outputFile=open("miRNA_primers.txt",'w')
##function to calculate melting temperature
def meltingTemperaure(primer_sequence):
    gcCount=primer_sequence.count('G')+primer_sequence.count('C')
    atCount=primer_sequence.count('A')+primer_sequence.count('T')
    meltingTemp=(2*atCount)+(4*gcCount)
    return meltingTemp;
def reverseComplement(seq):
    seq_dict = {'A':'T','T':'A','G':'C','C':'G'}
    return "".join([seq_dict[base] for base in reversed(seq)])

##the adaptors from NEB
data = [line.strip() for line in open("short_indexed_adaptors.txt", 'r')]

#class color:
    #RED='\033[31m'
    #GREEN='\033[32m'
    #END='\033[0m'

##forward primer
for i in range (0,len(mirna_fasta)):
    #header_line=''.join(map(str,mirna_fasta.keys()[i]))
    outputFile.write ("\n--->" + ''.join(map(str,list(mirna_fasta.keys())[i])) +'<---'+":" +'\n')
    mature_seq=''.join(map(str,list(mirna_fasta.values())[i]))
    outputFile.write ('Mature sequence='+mature_seq+'\n')
    adaptorList=random.sample(data,2)
    forwardPrimer_adaptor=''.join(map(str,adaptorList[0]))+''.join(map(str,adaptorList[1]))[:2]
    forwardPrimer_seq=mature_seq[:8].replace("U","T")
    forwardPrimer=forwardPrimer_adaptor+forwardPrimer_seq
    fp_meltingTemp= meltingTemperaure(forwardPrimer)    
    while fp_meltingTemp<50: # in any case the the melting temperature should not be lower than 50
        bases=["A","T","G","C"]
        forwardPrimer_adaptor=forwardPrimer_adaptor+random.choice(bases)
        forwardPrimer=forwardPrimer_adaptor+forwardPrimer_seq
        fp_meltingTemp= meltingTemperaure(forwardPrimer)
    else:
##the universal reverse primer
        reversePrimer="GTGCAGGGTCCGAGGT"   
        rp_meltingTemp= meltingTemperaure(reversePrimer) 
        while rp_meltingTemp-fp_meltingTemp>5: # the difference in the melting temperature shouldn't be less than 5 degrees
            reversePrimer=reversePrimer[1:]
            rp_meltingTemp= meltingTemperaure(reversePrimer)
        else:
            outputFile.write ('FP: 5`-'+forwardPrimer_adaptor+"'"+forwardPrimer_seq+"'"+'-3`\n')
            outputFile.write ('Tm(FP)='+str(fp_meltingTemp)+"\n")
            outputFile.write ('RP: 5`-'+reversePrimer+'-3`\n')
            outputFile.write ('Tm(RP)='+str(rp_meltingTemp)+"\n")
##for the RT primer
            threePrimeRevComp=reverseComplement(mature_seq[-5:].replace("U","T"))
            rtAdaptorList=random.sample(data,2)
            rtPrimer_adaptor=''.join(map(str,rtAdaptorList[0])) + ''.join(map(str,rtAdaptorList[1]))
            rtPrimer=reversePrimer+rtPrimer_adaptor+threePrimeRevComp
            outputFile.write ('RT-primer: 5`-'+reversePrimer+rtPrimer_adaptor+ "'"+threePrimeRevComp+"'"+'-3`'+'\n')

outputFile.close()
